#ifndef RTW_HEADER_motorFFT_capi_h
#define RTW_HEADER_motorFFT_capi_h
#include "motorFFT.h"
extern void motorFFT_InitializeDataMapInfo ( void ) ;
#endif
